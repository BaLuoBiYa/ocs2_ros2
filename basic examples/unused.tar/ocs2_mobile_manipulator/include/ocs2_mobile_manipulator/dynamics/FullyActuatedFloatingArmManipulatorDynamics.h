/******************************************************************************
Copyright (c) 2020, Farbod Farshidian. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

 * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************/

#pragma once

#include <ocs2_core/dynamics/SystemDynamicsBaseAD.h>

#include <ocs2_mobile_manipulator/ManipulatorModelInfo.h>
#include <ocs2_pinocchio_interface/PinocchioInterface.h>

namespace ocs2::mobile_manipulator
{
    /**
    * Implementation of dynamis for a free floating arm manipulator with actuatable base.
    *
    * The floating base manipulator has the state: (6-DOF base pose, arm joints).
    * The base orientation is represented using zyx euler angles.
    * The end-effector targets are assumed to given with respect to the world frame.
    * The arm is assumed to be velocity controlled.
    */
    class FullyActuatedFloatingArmManipulatorDynamics final : public SystemDynamicsBaseAD
    {
    public:
        /**
         * Constructor
         *
         * @param [in] modelInfo : The manipulator information.
         * @param [in] modelName : name of the generate model library
         * @param [in] modelFolder : folder to save the model library files to
         * @param [in] recompileLibraries : If true, always compile the model library, else try to load existing library if available.
         * @param [in] verbose : Display information.
         */
        FullyActuatedFloatingArmManipulatorDynamics(const ManipulatorModelInfo& modelInfo, const std::string& modelName,
                                                    const std::string& modelFolder = "/tmp/ocs2",
                                                    bool recompileLibraries = true,
                                                    bool verbose = true);

        ~FullyActuatedFloatingArmManipulatorDynamics() override = default;

        FullyActuatedFloatingArmManipulatorDynamics* clone() const override
        {
            return new FullyActuatedFloatingArmManipulatorDynamics(*this);
        }

    private:
        FullyActuatedFloatingArmManipulatorDynamics(const FullyActuatedFloatingArmManipulatorDynamics& rhs) = default;

        ad_vector_t systemFlowMap(ad_scalar_t time, const ad_vector_t& state, const ad_vector_t& input,
                                  const ad_vector_t& /*parameters*/) const override;
    };
}
