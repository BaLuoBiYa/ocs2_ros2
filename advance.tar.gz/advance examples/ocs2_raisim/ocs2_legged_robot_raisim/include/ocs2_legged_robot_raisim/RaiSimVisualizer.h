/******************************************************************************
Copyright (c) 2021, Farbod Farshidian. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

 * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************/

#pragma once

#include <ocs2_legged_robot_ros/visualization/LeggedRobotVisualizer.h>

#include <raisim/object/terrain/HeightMap.hpp>

namespace ocs2::legged_robot {
    class RaiSimVisualizer final : public LeggedRobotVisualizer {
    public:
        RaiSimVisualizer(
            PinocchioInterface interface,
            CentroidalModelInfo model_info,
            const PinocchioEndEffectorKinematics &endEffectorKinematics,
            rclcpp::Node::SharedPtr node, scalar_t maxUpdateFrequency = 100.0);

        ~RaiSimVisualizer() override = default;

        void update(const SystemObservation &observation,
                    const PrimalSolution &primalSolution,
                    const CommandData &command) override;

        void updateTerrain(std::chrono::seconds timeout = std::chrono::seconds(5));

    private:
        std::unique_ptr<raisim::HeightMap> terrainPtr_;
    };
} // namespace ocs2::legged_robot
