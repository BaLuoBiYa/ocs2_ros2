/******************************************************************************
Copyright (c) 2022, Farbod Farshidian. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

 * Neither the name of the copyright holder nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************/

#include "ocs2_ballbot_mpcnet/BallbotMpcnetDefinition.h"


namespace ocs2::ballbot {
    vector_t BallbotMpcnetDefinition::getObservation(scalar_t t, const vector_t &x, const ModeSchedule &modeSchedule,
                                                     const TargetTrajectories &targetTrajectories) {
        vector_t observation = x - targetTrajectories.getDesiredState(t);
        const Eigen::Matrix<scalar_t, 2, 2> R =
                (Eigen::Matrix<scalar_t, 2, 2>() << cos(x(2)), -sin(x(2)), sin(x(2)), cos(x(2))).finished().transpose();
        observation.segment<2>(0) = R * observation.segment<2>(0);
        observation.segment<2>(5) = R * observation.segment<2>(5);
        return observation;
    }

    std::pair<matrix_t, vector_t> BallbotMpcnetDefinition::getActionTransformation(scalar_t t, const vector_t &x,
        const ModeSchedule &modeSchedule,
        const TargetTrajectories &targetTrajectories) {
        return {matrix_t::Identity(3, 3), vector_t::Zero(3)};
    }

    bool BallbotMpcnetDefinition::isValid(scalar_t t, const vector_t &x, const ModeSchedule &modeSchedule,
                                          const TargetTrajectories &targetTrajectories) {
        return true;
    }
} // namespace ocs2::ballbot
